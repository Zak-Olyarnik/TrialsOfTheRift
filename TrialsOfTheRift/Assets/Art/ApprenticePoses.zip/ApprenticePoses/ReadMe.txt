Character Select Poses

These are all static models of the apprentice bodies and outfits. The only thing they need put on them is the texture maps that are included in this zip
Each outfit has two color variations: Sun and Moon, and the number of the texture map cooresponds to the outfit (ex. Apprentice 01 will require the texture maps Sun_01 and Moon 01)
Each player model needs to be duplicated, and have a sun texture, and a moon texture put on the outfit.
Each apprentice uses the same human diffuse map included in this zip




Victory

Enclosed in this folder are all 4 model variants in T-pose. for the victory screen, they will have animations applied to them, the animations are included here, there are two victory animations and two defeat animations
A new animator controller needs to be made with 1 animation as the default state and nothing else, so only state in the whole controller. 
When importing both the T-pose models and the animations, make sure to go to the rig tab in the import settings and change the rig type from generic to humanoid



Hats
The hats for everything need to be added in unity to make everything more modular, the hats are in the project folder, and while there are probably multiple ones, make sure to use the prefabs that already have the materials assigned to them, and parent them under the head root in the apprentices when you make the prefabs.